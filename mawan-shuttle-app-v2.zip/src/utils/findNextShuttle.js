
export function findNextShuttle(schedule, currentTime = new Date()) {
  const hour = currentTime.getHours()
  const minute = currentTime.getMinutes()

  const thisHourKey = hour.toString().padStart(2, '0')
  const minutes = schedule[thisHourKey] || []
  const nextMinute = minutes.find(m => m > minute)
  if (nextMinute !== undefined) {
    return new Date(currentTime.getFullYear(), currentTime.getMonth(), currentTime.getDate(), hour, nextMinute)
  }

  for (let h = hour + 1; h <= 22; h++) {
    const hKey = h.toString().padStart(2, '0')
    if (schedule[hKey] && schedule[hKey].length > 0) {
      return new Date(currentTime.getFullYear(), currentTime.getMonth(), currentTime.getDate(), h, schedule[hKey][0])
    }
  }

  return null
}
