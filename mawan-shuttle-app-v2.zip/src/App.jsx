
import { useEffect, useState } from 'react'
import schedule from './data/weekday.json'
import { findNextShuttle } from './utils/findNextShuttle'

function formatTime(date) {
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
}

function App() {
  const [nextBus, setNextBus] = useState(null)
  const [arrivalTime, setArrivalTime] = useState(null)

  useEffect(() => {
    const now = new Date()
    const next = findNextShuttle(schedule, now)
    if (next) {
      setNextBus(next)
      const arrival = new Date(next.getTime() + 15 * 60000)
      setArrivalTime(arrival)
    }
  }, [])

  return (
    <main className="p-4 max-w-md mx-auto text-center">
      <h1 className="text-2xl font-bold mb-4">Ma Wan → Tsing Yi</h1>
      {nextBus ? (
        <div className="bg-white shadow-md rounded-2xl p-4">
          <p>🚌 <strong>Next Shuttle:</strong> {formatTime(nextBus)}</p>
          <p>🚇 <strong>Arrives Tsing Yi:</strong> {formatTime(arrivalTime)}</p>
          <p className="text-sm text-gray-500 mt-2">(MTR timing coming soon)</p>
        </div>
      ) : (
        <p>No more buses today 💤</p>
      )}
    </main>
  )
}

export default App
